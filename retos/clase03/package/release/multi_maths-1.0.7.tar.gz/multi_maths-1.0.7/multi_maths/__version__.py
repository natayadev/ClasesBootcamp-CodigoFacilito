""" __version__ file for Multi_Maths Package """
# __doc__ (__version__ file for testing modules and packages)

VERSION = (1, 0, 7)

__version__ = '.'.join(map(str, VERSION))
