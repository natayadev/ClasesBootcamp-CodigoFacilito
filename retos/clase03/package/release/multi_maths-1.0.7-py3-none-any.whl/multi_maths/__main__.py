""" __main__ file for Multi_Maths Package """
# __doc__ (__main__ file for testing modules and packages)

from multi_maths.multi_maths import main

if __name__ == '__main__':
    main()
